# 🗂️ Log File Archiver

> A simple Bash script that automatically finds log files older than N days, compresses them with gzip, and moves them to a dated archive folder — keeping your system clean without manual effort.

---

## 📌 What it does

- Scans a directory (default: `/var/log`) for `.log` files
- Finds files **older than 30 days** (configurable)
- **Compresses** them using `gzip` (~70% size reduction)
- **Moves** them to `archive/YYYY-MM/` folder
- **Logs** every action to `logs/archiver.log`
- Can be **automated** with a cron job

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Bash | Main scripting language |
| `find` | Locate old log files |
| `gzip` | Compress files |
| `mv` | Move to archive folder |
| `cron` | Schedule daily runs |
| `stat` | Get file age in days |

---

## 📁 Project Structure

```
log-archiver/
├── archive_logs.sh      ← main archiver script
├── run.sh               ← easy launcher with menu
├── configs/
│   └── archiver.conf    ← settings (directory, days, pattern)
├── archive/
│   └── 2025-05/         ← compressed files go here (auto-created)
│       └── nginx.log.gz
├── logs/
│   └── archiver.log     ← what was archived and when
└── README.md
```

---

## ⚙️ Setup & Usage

### 1. Clone & set permissions
```bash
git clone https://github.com/YOUR_USERNAME/log-archiver.git
cd log-archiver
chmod +x run.sh archive_logs.sh
```

### 2. Edit config (optional)
```bash
nano configs/archiver.conf
```

```bash
LOG_DIR="/var/log"    # which folder to scan
DAYS=30               # archive files older than this
FILE_PATTERN="*.log"  # which files to match
```

### 3. Run it
```bash
# Easy way — interactive menu
sudo ./run.sh

# Direct way
sudo ./archive_logs.sh
```

### 4. Set up daily cron job
```bash
# Opens crontab editor
crontab -e

# Add this line (runs at 2AM every day)
0 2 * * * /path/to/log-archiver/archive_logs.sh >> /path/to/log-archiver/logs/cron.log 2>&1
```

Or let `run.sh` do it automatically — choose option **3** from the menu.

---

## 📊 Sample Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Log File Archiver
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Scanning  : /var/log
  Threshold : 30 days
  Archive   : ./archive/2025-05/
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  [OK]   nginx-access.log → ./archive/2025-05/ (31d old)
  [OK]   nginx-error.log  → ./archive/2025-05/ (45d old)
  [OK]   cron.log         → ./archive/2025-05/ (60d old)
  [SKIP] syslog.log (empty file)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Archived : 3 files
  Skipped  : 1 files
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 📚 Key Concepts Learned

- `find -mtime +30` — finds files modified more than 30 days ago
- `gzip -k` — compress and keep the original (`-k` = keep)
- `stat -c %Y` — get file's last modified timestamp in seconds
- `crontab` — schedule scripts to run automatically
- `while read` loop with `find -print0` — safe handling of filenames with spaces

---

## 🚀 Future Improvements

- [ ] Add email notification after each run
- [ ] Delete archives older than 1 year automatically
- [ ] Support multiple log directories
- [ ] Add dry-run mode (`--dry-run` flag) to preview without archiving
- [ ] Generate a summary report in HTML

---

## 📄 License

MIT License — free to use and modify.

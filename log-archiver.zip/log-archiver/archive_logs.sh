#!/bin/bash
# ============================================================
# archive_logs.sh — Log File Archiver
# Description: Finds log files older than N days, compresses
#              them with gzip, and moves to a dated archive.
# Usage: sudo ./archive_logs.sh
# ============================================================

# ── Load config ──────────────────────────────────────────────
CONFIG="$(dirname "$0")/configs/archiver.conf"
if [ -f "$CONFIG" ]; then
  source "$CONFIG"
else
  LOG_DIR="/var/log"
  ARCHIVE_DIR="$(dirname "$0")/archive"
  LOG_FILE="$(dirname "$0")/logs/archiver.log"
  DAYS=30
  FILE_PATTERN="*.log"
fi

# ── Colors ───────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

# ── Setup ────────────────────────────────────────────────────
DATE=$(date '+%Y-%m-%d %H:%M:%S')
MONTH=$(date '+%Y-%m')
DEST="$ARCHIVE_DIR/$MONTH"
ARCHIVED=0
SKIPPED=0
FAILED=0

mkdir -p "$DEST"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
  echo "$1"
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

# ── Banner ───────────────────────────────────────────────────
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}   Log File Archiver${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  Scanning  : ${LOG_DIR}"
echo -e "  Pattern   : ${FILE_PATTERN}"
echo -e "  Threshold : ${DAYS} days"
echo -e "  Archive   : ${DEST}/"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

log "=== Archive run started: $DATE ==="

# ── Main logic ───────────────────────────────────────────────
while IFS= read -r -d '' FILE; do

  FILENAME=$(basename "$FILE")
  AGE=$(( ( $(date +%s) - $(stat -c %Y "$FILE") ) / 86400 ))

  # Skip already compressed files
  if [[ "$FILENAME" == *.gz ]]; then
    continue
  fi

  # Skip empty files
  if [ ! -s "$FILE" ]; then
    echo -e "  ${YELLOW}[SKIP]${NC} $FILENAME (empty file)"
    log "  [SKIP] $FILENAME — empty"
    (( SKIPPED++ ))
    continue
  fi

  # Compress the file
  gzip -k "$FILE" 2>/dev/null
  if [ $? -ne 0 ]; then
    echo -e "  ${RED}[FAIL]${NC} $FILENAME — could not compress"
    log "  [FAIL] $FILENAME — gzip error"
    (( FAILED++ ))
    continue
  fi

  # Move compressed file to archive
  mv "${FILE}.gz" "$DEST/" 2>/dev/null
  if [ $? -ne 0 ]; then
    echo -e "  ${RED}[FAIL]${NC} $FILENAME — could not move to archive"
    log "  [FAIL] $FILENAME — mv error"
    (( FAILED++ ))
    continue
  fi

  echo -e "  ${GREEN}[OK]${NC}   $FILENAME → ${DEST}/ (${AGE}d old)"
  log "  [OK] $FILENAME → $DEST/ (${AGE}d old)"
  (( ARCHIVED++ ))

done < <(find "$LOG_DIR" -name "$FILE_PATTERN" -mtime +"$DAYS" -type f -print0 2>/dev/null)

# ── Summary ──────────────────────────────────────────────────
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${GREEN}Archived : $ARCHIVED files${NC}"
echo -e "  ${YELLOW}Skipped  : $SKIPPED files${NC}"
[ "$FAILED" -gt 0 ] && echo -e "  ${RED}Failed   : $FAILED files${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

log "=== Done — Archived: $ARCHIVED | Skipped: $SKIPPED | Failed: $FAILED ==="

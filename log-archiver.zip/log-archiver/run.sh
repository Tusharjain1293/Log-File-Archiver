#!/bin/bash
# ============================================================
# run.sh — Log Archiver Launcher
# Usage: sudo ./run.sh
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo -e "${CYAN}"
echo "  ██╗      ██████╗  ██████╗      █████╗ ██████╗  ██████╗██╗  ██╗██╗██╗   ██╗███████╗██████╗ "
echo "  ██║     ██╔═══██╗██╔════╝     ██╔══██╗██╔══██╗██╔════╝██║  ██║██║██║   ██║██╔════╝██╔══██╗"
echo "  ██║     ██║   ██║██║  ███╗    ███████║██████╔╝██║     ███████║██║██║   ██║█████╗  ██████╔╝"
echo "  ██║     ██║   ██║██║   ██║    ██╔══██║██╔══██╗██║     ██╔══██║██║╚██╗ ██╔╝██╔══╝  ██╔══██╗"
echo "  ███████╗╚██████╔╝╚██████╔╝    ██║  ██║██║  ██║╚██████╗██║  ██║██║ ╚████╔╝ ███████╗██║  ██║"
echo "  ╚══════╝ ╚═════╝  ╚═════╝     ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝"
echo -e "${NC}"
echo -e "  ${BOLD}Bash Log File Archiver${NC}"
echo -e "  ${YELLOW}Compresses & archives old .log files automatically${NC}"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── Root check ───────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERR]${NC} Please run with sudo: ${BOLD}sudo ./run.sh${NC}"
  exit 1
fi
echo -e "${GREEN}[✓]${NC} Running as root"

# ── Make scripts executable ──────────────────────────────────
chmod +x archive_logs.sh
echo -e "${GREEN}[✓]${NC} Scripts are executable"

# ── Create required folders ──────────────────────────────────
mkdir -p archive logs
echo -e "${GREEN}[✓]${NC} Folders ready"
echo ""

# ── Menu ─────────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo -e "  ${BOLD}${GREEN}1)${NC} Run archiver now"
echo -e "  ${BOLD}${GREEN}2)${NC} View archive log"
echo -e "  ${BOLD}${GREEN}3)${NC} Set up daily cron job (runs at 2AM)"
echo -e "  ${BOLD}${GREEN}4)${NC} Show archived files"
echo -e "  ${BOLD}${RED}0)${NC} Exit"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
read -rp "  Enter choice [0-4]: " CHOICE
echo ""

case "$CHOICE" in

  1)
    echo -e "${CYAN}Running archiver...${NC}"
    echo ""
    bash archive_logs.sh
    ;;

  2)
    LOG_FILE="./logs/archiver.log"
    if [ -f "$LOG_FILE" ]; then
      echo -e "${CYAN}── Archive Log ─────────────────────────${NC}"
      tail -50 "$LOG_FILE"
    else
      echo -e "${YELLOW}No log file yet. Run the archiver first.${NC}"
    fi
    ;;

  3)
    SCRIPT_PATH="$(realpath archive_logs.sh)"
    CRON_JOB="0 2 * * * $SCRIPT_PATH >> $(realpath logs)/cron.log 2>&1"
    (crontab -l 2>/dev/null | grep -v "archive_logs"; echo "$CRON_JOB") | crontab -
    echo -e "${GREEN}[✓]${NC} Cron job set! Archiver will run every day at 2:00 AM."
    echo ""
    echo -e "  Job: ${YELLOW}$CRON_JOB${NC}"
    echo ""
    echo -e "  View cron jobs: ${BOLD}crontab -l${NC}"
    ;;

  4)
    echo -e "${CYAN}── Archived Files ──────────────────────${NC}"
    if [ -d "./archive" ] && [ "$(ls -A ./archive 2>/dev/null)" ]; then
      find ./archive -name "*.gz" | sort | while read -r f; do
        SIZE=$(du -sh "$f" | cut -f1)
        echo -e "  ${GREEN}✓${NC} $(basename "$f")  [${SIZE}]"
      done
    else
      echo -e "  ${YELLOW}No archived files yet. Run the archiver first.${NC}"
    fi
    ;;

  0)
    echo -e "${GREEN}Bye! 👋${NC}"
    exit 0
    ;;

  *)
    echo -e "${RED}Invalid choice. Run ./run.sh again.${NC}"
    exit 1
    ;;
esac

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  Done!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
